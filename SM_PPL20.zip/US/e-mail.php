<?php


$xeonto = 'krypters.id@gmail.com';

$adminPass = 'admin123';



?>